package com.fsd.projectmanager.service;

import static org.junit.Assert.assertEquals;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.stereotype.Service;

import com.fsd.projectmanager.controller.ProjectManagerJSON;
import com.fsd.projectmanager.dao.ParentTask;
import com.fsd.projectmanager.dao.Project;
import com.fsd.projectmanager.dao.ProjectManagerDao;
import com.fsd.projectmanager.dao.Task;
import com.fsd.projectmanager.dao.User;

@Service("ProjectManagerService")
public class ProjectManagerServiceImplTest {
    
	@Mock
	private ProjectManagerDao projectManagerDao;
	
	@InjectMocks
	private ProjectManagerServiceImpl projectManagerServiceImpl;
	
	private Task task;
	private Project project;
	private User user;
	private ParentTask parentTask;
	private List<Task> taskList;
	private List<Task> gettaskList;
	private List<Project> projectList;
	private List<Project> getprojectList;
	private List<User> userList;
	private List<User> getuserList;
	private String status;
	
	@Before
    public void before() {		
		MockitoAnnotations.initMocks(this);		
		task = new Task();
		parentTask = new ParentTask();
		project = new Project();
		user = new User();
		taskList = new ArrayList<Task>();
		gettaskList = new ArrayList<Task>();
		projectList = new ArrayList<Project>();
		getprojectList = new ArrayList<Project>();
		userList = new ArrayList<User>();
		getuserList = new ArrayList<User>();
		status = null;
		createTaskObj();
		createProjectObj();
		createUserObj();
    }
    
	@Test
	public void addTaskTest() {
		Mockito.doNothing().when(this.projectManagerDao).addOrMergeTask(task);
		status = projectManagerServiceImpl.addTask(task);
		assertEquals("Task Added",status);
    }
	
	@Test
	public void updateTaskTest() {
		Mockito.doNothing().when(this.projectManagerDao).addOrMergeTask(task);
		status = projectManagerServiceImpl.updateTask(task);
		assertEquals("Task Updated",status);
    }
	
	@Test
	public void deleteTaskTest() {
		Mockito.doNothing().when(this.projectManagerDao).deleteTask(task);
		status = projectManagerServiceImpl.deleteTask(task);
		assertEquals("Task Deleted",status);
    }
	
	@Test
	public void getTaskListTest() {
		Mockito.doReturn(taskList).when(this.projectManagerDao).getAllTask();
		gettaskList = projectManagerServiceImpl.getTaskList();
		assertEquals(gettaskList.get(0).getTaskId(),taskList.get(0).getTaskId());
    }
	
	@Test
	public void addProjectTest() {
		Mockito.doNothing().when(this.projectManagerDao).addOrMergeProject(project);
		status = projectManagerServiceImpl.addProject(project);
		assertEquals("Project Added",status);
    }
	
	@Test
	public void updateProjectTest() {
		Mockito.doNothing().when(this.projectManagerDao).addOrMergeProject(project);
		status = projectManagerServiceImpl.updateProject(project);
		assertEquals("Project Updated",status);
    }
	
	@Test
	public void deleteProjectTest() {
		Mockito.doNothing().when(this.projectManagerDao).deleteProject(project);
		status = projectManagerServiceImpl.deleteProject(project);
		assertEquals("Project Deleted",status);
    }
	
	@Test
	public void getProjectListTest() {
		Mockito.doReturn(projectList).when(this.projectManagerDao).getAllProject();
		getprojectList = projectManagerServiceImpl.getProjectList();
		assertEquals(getprojectList.get(0).getProjectId(),projectList.get(0).getProjectId());
    }
	
	@Test
	public void addUserTest() {
		Mockito.doNothing().when(this.projectManagerDao).addOrMergeUser(user);
		status = projectManagerServiceImpl.addUser(user);
		assertEquals("User Added",status);
    }
	
	@Test
	public void updateUserTest() {
		Mockito.doNothing().when(this.projectManagerDao).addOrMergeUser(user);
		status = projectManagerServiceImpl.updateUser(user);
		assertEquals("User Updated",status);
    }
	
	@Test
	public void deleteUserTest() {
		Mockito.doNothing().when(this.projectManagerDao).deleteUser(user);
		status = projectManagerServiceImpl.deleteUser(user);
		assertEquals("User Deleted",status);
    }
	
	@Test
	public void getUserListTest() {
		Mockito.doReturn(userList).when(this.projectManagerDao).getAllUser();
		getuserList = projectManagerServiceImpl.getUserList();
		assertEquals(getuserList.get(0).getUser_Id(),userList.get(0).getUser_Id());
    }
	
	//Matching
	@Test
	public void getMatchingTaskTest() {
		Mockito.doReturn(task).when(this.projectManagerDao).getMatchingTask(task);
    	Task matchingTask = projectManagerServiceImpl.getMatchingTask(task);
    	assertEquals(task.getTaskId(),matchingTask.getTaskId());
    }
	
	@Test
	public void getMatchingProjectTest() {
		Mockito.doReturn(project).when(this.projectManagerDao).getMatchingProject(project);
		Project matchingProject = projectManagerServiceImpl.getMatchingProject(project);
    	assertEquals(project.getProjectId(),matchingProject.getProjectId());
    }
	
	@Test
	public void getMatchingUserTest() {
		Mockito.doReturn(user).when(this.projectManagerDao).getMatchingUser(user);
		User matchingUser = projectManagerServiceImpl.getMatchingUser(user);
    	assertEquals(user.getUser_Id(),matchingUser.getUser_Id());
    }
	
	@Test
	public void addParentTaskTest() {
		Mockito.doNothing().when(this.projectManagerDao).addOrMergeParentTask(parentTask);
		status = projectManagerServiceImpl.addParentTask(parentTask);
		assertEquals("Parent Task Added",status);
    }
	
	private void createTaskObj() {
		//Create a task object		
		task.setTaskName("Task1");
		parentTask.setParentaskName("ParentTask1");
		task.setParentTask(parentTask);
		task.setPriority(20);
		task.setStartDate(new java.sql.Date(new Date(12, 12, 2018).getTime()));
		task.setEndDate(new java.sql.Date(new Date(12, 12, 2018).getTime()));
		taskList.add(task);
	}
	
	private void createProjectObj() {
		//Create a project object		
		project.setProject("FSD TEST");
		project.setPriority(20);
		projectList.add(project);
	}
	
	private void createUserObj() {
		//Create a user object
		user.setEmployee_Id(1);
		user.setFirstName("FN");
		user.setLastName("LN");
		userList.add(user);
		
		
	}
}
