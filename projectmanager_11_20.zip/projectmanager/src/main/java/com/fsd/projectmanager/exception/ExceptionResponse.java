package com.fsd.projectmanager.exception;

import org.springframework.stereotype.Component;

@Component
public class ExceptionResponse {

	private int code;
	private String Description;
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}	
	
}
