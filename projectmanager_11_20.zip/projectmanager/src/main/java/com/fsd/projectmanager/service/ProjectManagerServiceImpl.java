package com.fsd.projectmanager.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fsd.projectmanager.dao.ParentTask;
import com.fsd.projectmanager.dao.Project;
import com.fsd.projectmanager.dao.ProjectManagerDao;
import com.fsd.projectmanager.dao.Task;
import com.fsd.projectmanager.dao.User;

@Service("ProjectManagerService")
public class ProjectManagerServiceImpl implements ProjectManagerService {
    
	@Autowired
	ProjectManagerDao projectMgrDaoImpl;
	
    /* (non-Javadoc)
     * @see com.fsd.taskmanager.TaskManagerService#addTask(com.fsd.taskmanager.Task)
     */
    public String addTask(Task task) {
    	projectMgrDaoImpl.addOrMergeTask(task);
        return "Task Added";
    }
    
    /* (non-Javadoc)
     * @see com.fsd.taskmanager.TaskManagerService#updateTask(com.fsd.taskmanager.Task)
     */
    public String updateTask(Task task) {
    	projectMgrDaoImpl.addOrMergeTask(task);
        return "Task Updated";
    }
    
    /* (non-Javadoc)
     * @see com.fsd.taskmanager.TaskManagerService#getTaskList()
     */
    public List<Task> getTaskList() {
    	List<Task> taskList = null;
    	taskList = projectMgrDaoImpl.getAllTask();    	
        return taskList;
    }
    
    /* (non-Javadoc)
     * @see com.fsd.taskmanager.TaskManagerService#deleteTask(com.fsd.taskmanager.Task)
     */
    public String deleteTask(Task task) {  
    	projectMgrDaoImpl.deleteTask(task);    	
        return "Task Deleted";
    }
    
    /* (non-Javadoc)
     * @see com.fsd.taskmanager.TaskManagerService#getMatchingTask(com.fsd.taskmanager.Task)
     */
    public Task getMatchingTask(Task task) {
    	Task matchingTask = projectMgrDaoImpl.getMatchingTask(task);
    	return matchingTask;
    }

	public User getMatchingUser(User user) {
		User matchingTask = projectMgrDaoImpl.getMatchingUser(user);
    	return matchingTask;
	}

	public String addUser(User user) {
		projectMgrDaoImpl.addOrMergeUser(user);
        return "User Added";
	}

	public Project getMatchingProject(Project project) {
		Project matchingProject = projectMgrDaoImpl.getMatchingProject(project);
    	return matchingProject;
	}

	public String addProject(Project project) {
		projectMgrDaoImpl.addOrMergeProject(project);
        return "Project Added";
	}

	public List<Project> getProjectList() {
		List<Project> projectList = null;
		projectList = projectMgrDaoImpl.getAllProject();    	
        return projectList;
	}

	public String updateProject(Project project) {
		projectMgrDaoImpl.addOrMergeProject(project);
        return "Project Updated";
	}

	public String deleteProject(Project project) {
		projectMgrDaoImpl.deleteProject(project);    	
        return "Project Deleted";
	}

	public List<User> getUserList() {
		List<User> userList = null;
		userList = projectMgrDaoImpl.getAllUser();    	
        return userList;
	}

	public String updateUser(User user) {
		projectMgrDaoImpl.addOrMergeUser(user);
        return "User Updated";
	}

	public String deleteUser(User user) {
		projectMgrDaoImpl.deleteUser(user);    	
        return "User Deleted";
	}

	public String addParentTask(ParentTask parentTask) {
		projectMgrDaoImpl.addOrMergeParentTask(parentTask);
        return "Parent Task Added";
	}

	public List<ParentTask> getParentTaskList() {
		List<ParentTask> parentTaskList = null;
		parentTaskList = projectMgrDaoImpl.getAllParentTask();    	
        return parentTaskList;
	}
}
