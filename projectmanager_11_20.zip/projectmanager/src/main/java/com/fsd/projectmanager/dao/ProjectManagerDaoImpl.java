package com.fsd.projectmanager.dao;

import java.util.List;
import javax.persistence.EntityManagerFactory;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.fsd.projectmanager.dao.ProjectManagerDao;
 
@Repository("TaskDao")
public class ProjectManagerDaoImpl implements ProjectManagerDao{
	
	private static final Logger log = LoggerFactory.getLogger(ProjectManagerDaoImpl.class);
	
	@Autowired
	private EntityManagerFactory entityManagerFactory;
	
	/* (non-Javadoc)
	 * @see com.fsd.taskmanager.TaskDao#addOrMergeTask(com.fsd.taskmanager.Task)
	 */
	public void addOrMergeTask(Task task) {
		log.info("Inside dao method: addOrMergeTask");
		Session session = entityManagerFactory.unwrap(SessionFactory.class).openSession();
		Transaction tx = session.beginTransaction();
		try {
			session.saveOrUpdate(task);
		}catch (RuntimeException e) {
			session.close();
			throw new RuntimeException("Error occured in addOrMergeTask",e);
        }finally{
        	tx.commit();
        	session.close();
        }
	}
	
	//public ParentTask getParenTaskById(){
//		
	//}
	/* (non-Javadoc)
	 * @see com.fsd.taskmanager.TaskDao#deleteTask(com.fsd.taskmanager.Task)
	 */
	public void deleteTask(Task task) {
		log.info("Inside dao method: deleteTask");
	   	Session session = entityManagerFactory.unwrap(SessionFactory.class).openSession();
        Transaction tx = session.beginTransaction();
          
        try{
        	session.load(task, task.getTaskId());
            session.delete(task);
          }catch (RuntimeException e) {
              session.close();
        	  throw new RuntimeException("Error occured in deleteTask",e);
          }finally{
        	  tx.commit();
        	  session.close();
          }
	}

	/* (non-Javadoc)
    * @see com.fsd.taskmanager.TaskDao#getAllTask()
    */
	public List<Task> getAllTask() {
	   log.info("Inside dao method: getAllTask");
	   Session session = entityManagerFactory.unwrap(SessionFactory.class).openSession();           
	   List<Task> taskList = null;
       try{
    	   taskList = session.createCriteria(Task.class).list();       	           	    
       }catch (RuntimeException e) {
    	   throw new RuntimeException("Error occured in getAllTask",e);
       }    	  
       return taskList;    	   
   }
	
	/* (non-Javadoc)
	 * @see com.fsd.taskmanager.TaskDao#getMatchingTask(com.fsd.taskmanager.Task)
	 */
	public Task getMatchingTask(Task task) {
		log.info("Inside dao method: getTaskByName");
	   	Session session = entityManagerFactory.unwrap(SessionFactory.class).openSession();
        Transaction tx = session.beginTransaction();
          
        try{
        	
        	Criteria criteria = session.createCriteria(Task.class);
        	criteria.add(Restrictions.eq("taskName", task.getTaskName()));
        	criteria.add(Restrictions.eq("startDate", task.getStartDate()));
        	criteria.add(Restrictions.eq("endDate", task.getEndDate()));
        	criteria.add(Restrictions.eq("priority", task.getPriority()));
        	Task matchingTask = (Task) criteria.uniqueResult();
        	
        	return matchingTask;
          }catch (RuntimeException e) {
              session.close();
        	  throw new RuntimeException("Error occured in getMatchingTask",e);
          }finally{
        	  tx.commit();
        	  session.close();
          }
	}

	@Override
	public User getMatchingUser(User user) {

		log.info("Inside dao method: getMatchingUser");
	   	Session session = entityManagerFactory.unwrap(SessionFactory.class).openSession();
        Transaction tx = session.beginTransaction();
          
        try{
        	
        	Criteria criteria = session.createCriteria(User.class);
        	criteria.add(Restrictions.eq("user_Id", user.getUser_Id()));
        	criteria.add(Restrictions.eq("employee_Id", user.getEmployee_Id()));
        	criteria.add(Restrictions.eq("firstName", user.getFirstName()));
        	criteria.add(Restrictions.eq("lastName", user.getLastName()));
        	User matchingUser = (User) criteria.uniqueResult();
        	
        	return matchingUser;
          }catch (Exception e) {
              session.close();
        	  throw new RuntimeException("Error occured in getMatchingUser",e);
          }finally{
        	  tx.commit();
        	  session.close();
          }
	
	}

	@Override
	public void addOrMergeUser(User user) {
		log.info("Inside dao method: addOrMergeUser");
		Session session = entityManagerFactory.unwrap(SessionFactory.class).openSession();
		Transaction tx = session.beginTransaction();
		try {
			session.saveOrUpdate(user);
		}catch (RuntimeException e) {
			session.close();
			throw new RuntimeException("Error occured in addOrMergeUser",e);
        }finally{
        	tx.commit();
        	session.close();
        }
		
	}

	@Override
	public void addOrMergeProject(Project project) {
		log.info("Inside dao method: addOrMergeProject");
		Session session = entityManagerFactory.unwrap(SessionFactory.class).openSession();
		Transaction tx = session.beginTransaction();
		try {
			session.saveOrUpdate(project);
		}catch (RuntimeException e) {
			session.close();
			throw new RuntimeException("Error occured in addOrMergeProject",e);
        }finally{
        	tx.commit();
        	session.close();
        }
		
	}

	@Override
	public Project getMatchingProject(Project project) {

		log.info("Inside dao method: getMatchingProject");
	   	Session session = entityManagerFactory.unwrap(SessionFactory.class).openSession();
        Transaction tx = session.beginTransaction();
          
        try{
        	
        	Criteria criteria = session.createCriteria(Project.class);
        	criteria.add(Restrictions.eq("projectId", project.getProjectId()));
        	if(project.getProject()!=null && project.getStartDate()!=null && project.getEndDate()!=null) {
        		criteria.add(Restrictions.eq("Project", project.getProject()));
            	criteria.add(Restrictions.eq("startDate", project.getStartDate()));
            	criteria.add(Restrictions.eq("endDate", project.getEndDate()));
            	criteria.add(Restrictions.eq("priority", project.getPriority()));
        	}        	
        	Project matchingProject = (Project) criteria.uniqueResult();
        	
        	return matchingProject;
          }catch (Exception e) {
              session.close();
        	  throw new RuntimeException("Error occured in getMatchingProject",e);
          }finally{
        	  tx.commit();
        	  session.close();
          }
	
	}

	@Override
	public List<Project> getAllProject() {

		   log.info("Inside dao method: getAllProject");
		   Session session = entityManagerFactory.unwrap(SessionFactory.class).openSession();           
		   List<Project> projectList = null;
	       try{
	    	   projectList = session.createCriteria(Project.class).list();       	           	    
	       }catch (Exception e) {
	    	   throw new RuntimeException("Error occured in getAllProject",e);
	       }    	  
	       return projectList;    	   
	   
	}

	@Override
	public void deleteProject(Project project) {
		log.info("Inside dao method: deleteProject");
	   	Session session = entityManagerFactory.unwrap(SessionFactory.class).openSession();
        Transaction tx = session.beginTransaction();
          
        try{
        	session.load(project, project.getProjectId());
            session.delete(project);
          }catch (Exception e) {
              session.close();
        	  throw new RuntimeException("Error occured in deleteProject",e);
          }finally{
        	  tx.commit();
        	  session.close();
          }
	}

	@Override
	public List<User> getAllUser() {

		   log.info("Inside dao method: getAllUser");
		   Session session = entityManagerFactory.unwrap(SessionFactory.class).openSession();           
		   List<User> userList = null;
	       try{
	    	   userList = session.createCriteria(User.class).list();       	           	    
	       }catch (Exception e) {
	    	   throw new RuntimeException("Error occured in getAllUser",e);
	       }    	  
	       return userList;    	   
	   
	}

	@Override
	public void deleteUser(User user) {
		log.info("Inside dao method: deleteUser");
	   	Session session = entityManagerFactory.unwrap(SessionFactory.class).openSession();
        Transaction tx = session.beginTransaction();
          
        try{
        	session.load(user, user.getUser_Id());
            session.delete(user);
          }catch (Exception e) {
              session.close();
        	  throw new RuntimeException("Error occured in deleteUser",e);
          }finally{
        	  tx.commit();
        	  session.close();
          }
	}

	@Override
	public void addOrMergeParentTask(ParentTask parentTask) {

		log.info("Inside dao method: addOrMergeParentTask");
		Session session = entityManagerFactory.unwrap(SessionFactory.class).openSession();
		Transaction tx = session.beginTransaction();
		try {
			session.saveOrUpdate(parentTask);
		}catch (RuntimeException e) {
			session.close();
			throw new RuntimeException("Error occured in addOrMergeParentTask",e);
        }finally{
        	tx.commit();
        	session.close();
        }
	}

	@Override
	public List<ParentTask> getAllParentTask() {
		log.info("Inside dao method: getAllParentTask");
		   Session session = entityManagerFactory.unwrap(SessionFactory.class).openSession();           
		   List<ParentTask> parentTaskList = null;
	       try{
	    	   parentTaskList = session.createCriteria(ParentTask.class).list();       	           	    
	       }catch (RuntimeException e) {
	    	   throw new RuntimeException("Error occured in getAllParentTask",e);
	       }    	  
	    return parentTaskList;
	}
       
}