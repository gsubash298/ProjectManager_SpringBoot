package com.fsd.projectmanager.controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude
public class TaskManagerJSON {

	private int taskId;	
	private int parentId;
	@NotEmpty (message="Please enter the taskName")
	private String task;
	private String parentTask;
	@NotNull(message="Please enter the startDate")
	private Date startDate;
	@NotNull(message="Please enter the endDate")
	private Date endDate;
	@NotNull(message="Please select the Priority")
	private Integer priority;
	private String status;
	
	private int projectId;
	private String project;
	private Date projectStartDate;
	private Date projectEndDate;
	private int projectPriority;
	
	private int userId;
	private String firstName;
	private String lastName;
	private int employeeId;
	
	public int getProjectId() {
		return projectId;
	}
	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}
	public String getProject() {
		return project;
	}
	public void setProject(String project) {
		this.project = project;
	}
	public Date getProjectStartDate() {
		return projectStartDate;
	}
	public void setProjectStartDate(Date projectStartDate) {
		this.projectStartDate = projectStartDate;
	}
	public Date getProjectEndDate() {
		return projectEndDate;
	}
	public void setProjectEndDate(Date projectEndDate) {
		this.projectEndDate = projectEndDate;
	}
	public int getProjectPriority() {
		return projectPriority;
	}
	public void setProjectPriority(int projectPriority) {
		this.projectPriority = projectPriority;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	
	public int getTaskId() {
		return taskId;
	}
	public void setTaskId(int taskId) {
		this.taskId = taskId;
	}
	public int getParentId() {
		return parentId;
	}
	public void setParentId(int parentId) {
		this.parentId = parentId;
	}
	public String getTask() {
		return task;
	}
	public void setTask(String task) {
		this.task = task;
	}
	public String getParentTask() {
		return parentTask;
	}
	public void setParentTask(String parentTask) {
		this.parentTask = parentTask;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public Integer getPriority() {
		return priority;
	}
	public void setPriority(Integer priority) {
		this.priority = priority;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	private DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd");
	
	public String toString(){		
		return "taskId :"+this.taskId+","+
				"ParentId :"+this.parentId+","+
				"task :"+this.task+","+
				"parentTask :"+this.parentTask+","+
				"startDate :"+dateFormat.format(this.startDate)+","+
				"endDate :"+dateFormat.format(this.endDate)+","+
				"priority :"+this.priority+"\n";
		
	}
	
}
