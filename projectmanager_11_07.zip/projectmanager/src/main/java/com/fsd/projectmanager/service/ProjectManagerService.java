package com.fsd.projectmanager.service;

import java.util.List;

import com.fsd.projectmanager.dao.Task;

public interface ProjectManagerService {
	String addTask(Task task);
	String updateTask(Task task);
	List<Task> getTaskList();
	String deleteTask(Task task);
	Task getMatchingTask(Task task);
}
