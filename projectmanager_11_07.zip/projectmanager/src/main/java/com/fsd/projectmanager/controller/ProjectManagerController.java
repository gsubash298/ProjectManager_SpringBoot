package com.fsd.projectmanager.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import com.fsd.projectmanager.dao.ParentTask;
import com.fsd.projectmanager.dao.Project;
import com.fsd.projectmanager.dao.Task;
import com.fsd.projectmanager.dao.User;
import com.fsd.projectmanager.exception.ExceptionResponse;
import com.fsd.projectmanager.exception.UserException;
import com.fsd.projectmanager.service.ProjectManagerServiceImpl;
import com.fsd.projectmanager.service.ProjectManagerServiceImplTest;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.validation.Valid;

@CrossOrigin(origins = "http://localhost:4200", maxAge = 3600, allowedHeaders="*")
@RestController
@RequestMapping({"/projectManager"})
public class ProjectManagerController {
	
	private static final Logger log = LoggerFactory.getLogger(ProjectManagerController.class);
    @Autowired
    private ProjectManagerServiceImpl projectManageService;
    
    private String status = null;
    
    private Map<String,String> validationList;
        
    /**
     * This method is to create the task
     * @param projectManageJSON
     * @return
     * @throws ParseException
     */
    @PostMapping({"/task"})
    public ResponseEntity<Object> createTask(@RequestBody @Validated(ProjectManagerJSON.ValidationOne.class) ProjectManagerJSON projectManageJSON, BindingResult bindingResult) throws RuntimeException, UserException{
    	
    	log.info("Inside create Task method {}", projectManageJSON);
    	
    	if(bindingResult != null && bindingResult.hasErrors()) {
    		validationList = new HashMap<String,String>();
    		for(FieldError fieldError: bindingResult.getFieldErrors()) {
    			validationList.put(fieldError.getField(), fieldError.getDefaultMessage());
    		}
    		return new ResponseEntity<Object>(validationList,HttpStatus.NOT_ACCEPTABLE);
    	}
    	
    	//Create task and parent task entity object
    	Task task = new Task();
    	ParentTask parentTask = new ParentTask();
    	Project project = new Project();
    	User user = new User();
    	
    	//setting the JSON object to the the task and parent task bean
    	task.setTaskName(projectManageJSON.getTask());
    	
    	task.setParentTask(parentTask);
    	task.getParentTask().setParentaskName(projectManageJSON.getParentTask());
    	task.getParentTask().setParentId(projectManageJSON.getParentId());
    	
    	project.setProjectId(projectManageJSON.getProjectId());
    	task.setProject(project);
    	
    	user.setUser_Id(projectManageJSON.getUserId());
    	task.setUser(user);
    	    	
    	//Get the sql date from the util date object
    	java.sql.Date sqlStartDate = new java.sql.Date(projectManageJSON.getStartDate().getTime());
    	java.sql.Date sqlEndDate = new java.sql.Date(projectManageJSON.getStartDate().getTime());
    	task.setStartDate(sqlStartDate);
    	task.setEndDate(sqlEndDate);
    	task.setPriority(projectManageJSON.getPriority());
    	task.setStatus(projectManageJSON.getStatus());
    	
    	Task matchingTask = projectManageService.getMatchingTask(task);
    	
    	if (matchingTask != null) {    		
    		UserException ue = new UserException();
    		ue.setCode(HttpStatus.CONFLICT.value());
    		ue.setMessage("Task with same taskname, startDate, EndDate, priority is already existed");
    		throw ue;
    	}

    	//Call the add task method
    	status = projectManageService.addTask(task);
    	if ("Task Added".equals(status)) {
    		log.info("Task is created successfully --> status =  {}", status);
    	}
    	return new ResponseEntity<Object>(projectManageJSON,HttpStatus.OK);
    }
    
    /**
     * This method is to derive the list of task
     * @return projectManageJSONList
     */
    @GetMapping({"/task"})
    public List<ProjectManagerJSON> getTaskList(){    	
    	//Create projectManagerJSON list object
    	log.info("Inside getTaskList method");
    	List<ProjectManagerJSON> projectManageJSONList = new ArrayList<ProjectManagerJSON>();    	
    	List<Task> listOfTask = projectManageService.getTaskList();
    	for (Task task: listOfTask){
    		ProjectManagerJSON projectManageJSON = new ProjectManagerJSON();
    		projectManageJSON.setTaskId(task.getTaskId());
    		projectManageJSON.setTask(task.getTaskName());
    		projectManageJSON.setPriority(task.getPriority());    		    		
    		projectManageJSON.setStartDate(task.getStartDate());
    		projectManageJSON.setEndDate(task.getEndDate());
    		projectManageJSON.setStatus(task.getStatus());
    		if(task.getParentTask() != null) {
    			projectManageJSON.setParentId(task.getParentTask().getParentId());
    			projectManageJSON.setParentTask(task.getParentTask().getParentaskName());
    		}
    		if(task.getProject() != null) {
    			projectManageJSON.setProjectId(task.getProject().getProjectId());
    			projectManageJSON.setProject(task.getProject().getProject());
    			projectManageJSON.setProjectStartDate(task.getProject().getStartDate());
    			projectManageJSON.setProjectEndDate(task.getProject().getEndDate());
    			projectManageJSON.setProjectPriority(task.getProject().getPriority());
    		}
    		if(task.getUser() != null) {
    			projectManageJSON.setUserId(task.getUser().getUser_Id());
    			projectManageJSON.setEmployeeId(task.getUser().getEmployee_Id());
    			projectManageJSON.setFirstName(task.getUser().getFirstName());
    			projectManageJSON.setLastName(task.getUser().getLastName());
    		}
    		projectManageJSONList.add(projectManageJSON);
    	}
    	log.info("List of task retrieved: \n {}", projectManageJSONList);
		return projectManageJSONList;        
    }
    
    @PutMapping({"/task"})
    public ResponseEntity<ProjectManagerJSON> updateTask(@RequestBody ProjectManagerJSON projectManageJSON) throws ParseException{
    	
    	log.info("Inside update Task method {}", projectManageJSON);
    	
    	//Create task and parent task entity object
    	Task task = new Task();
    	ParentTask parentTask = new ParentTask();
    	Project project = new Project();
    	User user = new User();
    	
    	//setting the JSON object to the the task and parent task bean
    	task.setTaskName(projectManageJSON.getTask());
    	task.setTaskId(projectManageJSON.getTaskId());
    	task.setParentTask(parentTask);
    	task.getParentTask().setParentaskName(projectManageJSON.getParentTask());
    	task.getParentTask().setParentId(projectManageJSON.getParentId());
    	
    	project.setProjectId(projectManageJSON.getProjectId());
    	task.setProject(project);
    	
    	user.setUser_Id(projectManageJSON.getUserId());
    	task.setUser(user);
    	    	
    	//Get the sql date from the util date object
    	java.sql.Date sqlStartDate = new java.sql.Date(projectManageJSON.getStartDate().getTime());
    	java.sql.Date sqlEndDate = new java.sql.Date(projectManageJSON.getStartDate().getTime());
    	task.setStartDate(sqlStartDate);
    	task.setEndDate(sqlEndDate);
    	task.setPriority(projectManageJSON.getPriority());
    	task.setStatus(projectManageJSON.getStatus());
    	
    	status = projectManageService.updateTask(task);
    	if ("Task Updated".equals(status)) {
    		log.info("Task is updated successfully --> status =  {}", status);
    	}
    	return new ResponseEntity<ProjectManagerJSON>(projectManageJSON,HttpStatus.OK);
    }
    
    @DeleteMapping(path ={"/task/{taskId}"})
    public ResponseEntity<Integer> deleteTask(int taskId) {
    	log.info("Inside delete Task method {}", taskId);
    	Task task = new Task();    	
    	task.setTaskId(taskId);
    	
    	status = projectManageService.deleteTask(task);
    	if ("Task Deleted".equals(status)) {
    		log.info("Task is deleted successfully --> status =  {}", status);
    	}
    	return new ResponseEntity<Integer>(taskId,HttpStatus.OK);
    }
    
    /**
     * This method is to create the Parent task
     * @param projectManageJSON
     * @return
     * @throws ParseException
     */
    @PostMapping({"/parentTask"})
    public ResponseEntity<Object> createParentTask(@RequestBody ProjectManagerJSON projectManageJSON, BindingResult bindingResult) throws RuntimeException, UserException{
    	
    	log.info("Inside create Parent Task method {}", projectManageJSON);
    	
    	//Create parent task entity object
    	ParentTask parentTask = new ParentTask();
    	parentTask.setParentaskName(projectManageJSON.getParentTask());
    	
    	//Call the add Parent task method
    	status = projectManageService.addParentTask(parentTask);
    	if ("Parent Task Added".equals(status)) {
    		log.info("Parent Task is created successfully --> status =  {}", status);
    	}
    	return new ResponseEntity<Object>(projectManageJSON,HttpStatus.OK);
    }
    
    @PostMapping({"/project"})
    public ResponseEntity<Object> createProject(@RequestBody ProjectManagerJSON projectManageJSON, BindingResult bindingResult) throws RuntimeException, UserException{
    	
    	log.info("Inside create project method {}", projectManageJSON);
    	
    	Project project = new Project();
    	project.setProject(projectManageJSON.getProject());
    	project.setStartDate(new java.sql.Date(projectManageJSON.getProjectStartDate().getTime()));
    	project.setEndDate(new java.sql.Date(projectManageJSON.getProjectEndDate().getTime()));
    	project.setPriority(projectManageJSON.getProjectPriority());
    	
    	User user = new User();
    	user.setUser_Id(projectManageJSON.getUserId());
    	project.setUser(user);
    	
    	Project matchingProject = projectManageService.getMatchingProject(project);
    	
    	if (matchingProject != null) {    		
    		UserException ue = new UserException();
    		ue.setCode(HttpStatus.CONFLICT.value());
    		ue.setMessage("Project is already existed");
    		throw ue;
    	}

    	//Call the add task method
    	status = projectManageService.addProject(project);
    	if ("Project Added".equals(status)) {
    		log.info("Project is created successfully --> status =  {}", status);
    	}
    	return new ResponseEntity<Object>(projectManageJSON,HttpStatus.OK);
    }
    
    /**
     * This method is to derive the list of task
     * @return projectManageJSONList
     */
    @GetMapping({"/project"})
    public List<ProjectManagerJSON> getProjectList(){    	
    	//Create projectManagerJSON list object
    	log.info("Inside getProjectList method");
    	List<ProjectManagerJSON> projectManageJSONList = new ArrayList<ProjectManagerJSON>();    	
    	List<Project> listOfProject = projectManageService.getProjectList();
    	for (Project project: listOfProject){
    		ProjectManagerJSON projectManageJSON = new ProjectManagerJSON();
    		projectManageJSON.setProjectId(project.getProjectId());
    		projectManageJSON.setProject(project.getProject());
    		projectManageJSON.setProjectPriority(project.getPriority());    		    		
    		projectManageJSON.setProjectStartDate(project.getStartDate());
    		projectManageJSON.setProjectEndDate(project.getEndDate());
    		if(project.getUser() != null) {
    			projectManageJSON.setEmployeeId(project.getUser().getEmployee_Id());
    			projectManageJSON.setUserId(project.getUser().getUser_Id());
    			projectManageJSON.setFirstName(project.getUser().getFirstName());
    			projectManageJSON.setLastName(project.getUser().getLastName());
    		}
    		
    		Set<TaskManagerJSON> taskManagerList = new HashSet<TaskManagerJSON>();
    		
    		if(!project.getTask().isEmpty() && project.getTask() != null) {
    			for (Task task: project.getTask()) {
    				TaskManagerJSON taskManagerJSON = new TaskManagerJSON();
    				taskManagerJSON.setTaskId(task.getTaskId());
    				taskManagerJSON.setTask(task.getTaskName());
    				taskManagerJSON.setPriority(task.getPriority());
    				taskManagerJSON.setStartDate(task.getStartDate());
    				taskManagerJSON.setEndDate(task.getEndDate());
    				taskManagerJSON.setStatus(task.getStatus());
    				
    				taskManagerList.add(taskManagerJSON);
    			}
    			projectManageJSON.setTaskManagerList(taskManagerList);
    		}
    		projectManageJSONList.add(projectManageJSON);
    	}
    	log.info("List of project retrieved: \n {}", projectManageJSONList);
		return projectManageJSONList;        
    }
    
    @PutMapping({"/project"})
    public ResponseEntity<ProjectManagerJSON> updateProject(@RequestBody ProjectManagerJSON projectManageJSON) throws ParseException{
    	
    	log.info("Inside update project method {}", projectManageJSON);
    	Project project = new Project();
    	project.setProject(projectManageJSON.getProject());
    	project.setProjectId(projectManageJSON.getProjectId());
    	project.setStartDate(new java.sql.Date(projectManageJSON.getProjectStartDate().getTime()));
    	project.setEndDate(new java.sql.Date(projectManageJSON.getProjectEndDate().getTime()));
    	project.setPriority(projectManageJSON.getProjectPriority());
    	
    	User user = new User();
    	user.setUser_Id(projectManageJSON.getUserId());
    	project.setUser(user);
    	
    	status = projectManageService.updateProject(project);
    	if ("Project Updated".equals(status)) {
    		log.info("Task is updated successfully --> status =  {}", status);
    	}
    	return new ResponseEntity<ProjectManagerJSON>(projectManageJSON,HttpStatus.OK);
    }
    
    @DeleteMapping(path ={"/project/{projectId}"})
    public ResponseEntity<Integer> deleteProject(int projectId) {
    	log.info("Inside delete Project method {}", projectId);
    	Project project = new Project();    	
    	project.setProjectId(projectId);
    	
    	status = projectManageService.deleteProject(project);
    	if ("Project Deleted".equals(status)) {
    		log.info("Project is deleted successfully --> status =  {}", status);
    	}
    	return new ResponseEntity<Integer>(projectId,HttpStatus.OK);
    }
    
    @PostMapping({"/user"})
    public ResponseEntity<Object> createUser(@RequestBody @Validated(ProjectManagerJSON.ValidationTwo.class) ProjectManagerJSON projectManageJSON, BindingResult bindingResult) throws RuntimeException, UserException{
    	
    	log.info("Inside create user method {}", projectManageJSON);
    	
    	if(bindingResult != null && bindingResult.hasErrors()) {
    		validationList = new HashMap<String,String>();
    		for(FieldError fieldError: bindingResult.getFieldErrors()) {
    			validationList.put(fieldError.getField(), fieldError.getDefaultMessage());
    		}
    		return new ResponseEntity<Object>(validationList,HttpStatus.NOT_ACCEPTABLE);
    	}
    	
    	User user = new User();
    	user.setEmployee_Id(projectManageJSON.getEmployeeId());
    	user.setFirstName(projectManageJSON.getFirstName());
    	user.setLastName(projectManageJSON.getLastName());
    	
    	User matchingUser = projectManageService.getMatchingUser(user);
    	
    	if (matchingUser != null) {    		
    		UserException ue = new UserException();
    		ue.setCode(HttpStatus.CONFLICT.value());
    		ue.setMessage("User is already existed");
    		throw ue;
    	}

    	//Call the add task method
    	status = projectManageService.addUser(user);
    	if ("User Added".equals(status)) {
    		log.info("User is created successfully --> status =  {}", status);
    	}
    	return new ResponseEntity<Object>(projectManageJSON,HttpStatus.OK);
    }
    
    /**
     * This method is to derive the list of task
     * @return projectManageJSONList
     */
    @GetMapping({"/user"})
    public List<ProjectManagerJSON> getUserList(){    	
    	//Create projectManagerJSON list object
    	log.info("Inside getUserList method");
    	List<ProjectManagerJSON> projectManageJSONList = new ArrayList<ProjectManagerJSON>();    	
    	List<User> listOfUser = projectManageService.getUserList();
    	for (User user:listOfUser){
    		ProjectManagerJSON projectManageJSON = new ProjectManagerJSON();
    		projectManageJSON.setUserId(user.getUser_Id());
    		projectManageJSON.setEmployeeId(user.getEmployee_Id());
    		projectManageJSON.setFirstName(user.getFirstName());    		    		
    		projectManageJSON.setLastName(user.getLastName());
    		projectManageJSONList.add(projectManageJSON);
    	}
    	log.info("List of User retrieved: \n {}", projectManageJSONList);
		return projectManageJSONList;        
    }
    
    @PutMapping({"/user"})
    public ResponseEntity<ProjectManagerJSON> updateUser(@RequestBody ProjectManagerJSON projectManageJSON) throws ParseException{
    	
    	log.info("Inside update Task method {}", projectManageJSON);
    	//Create task and parent task entity object
    	Task task = new Task();
    	ParentTask parentTask = new ParentTask();
    	
    	User user = new User();
    	user.setEmployee_Id(projectManageJSON.getEmployeeId());
    	user.setFirstName(projectManageJSON.getFirstName());
    	user.setLastName(projectManageJSON.getLastName());
    	user.setUser_Id(projectManageJSON.getUserId());
    	
    	status = projectManageService.updateUser(user);
    	if ("User Updated".equals(status)) {
    		log.info("User is updated successfully --> status =  {}", status);
    	}
    	return new ResponseEntity<ProjectManagerJSON>(projectManageJSON,HttpStatus.OK);
    }
    
    @DeleteMapping(path ={"/user/{userId}"})
    public ResponseEntity<Integer> deleteUser(int userId) {
    	log.info("Inside delete Task method {}", userId);
    	User user = new User();    	
    	user.setUser_Id(userId);
    	
    	status = projectManageService.deleteUser(user);
    	if ("User Deleted".equals(status)) {
    		log.info("User is deleted successfully --> status =  {}", status);
    	}
    	return new ResponseEntity<Integer>(userId,HttpStatus.OK);
    }
    
}
