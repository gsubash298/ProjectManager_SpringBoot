package com.fsd.projectmanager.dao;

import javax.persistence.EntityManagerFactory;
import static org.junit.Assert.*;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.stereotype.Repository;
 
@Repository("TaskDao")
public class ProjectManagerDaoImplTest{
	
	@Mock
	private EntityManagerFactory entityManagerFactory;
	
	@InjectMocks
	private ProjectManagerDaoImpl projectManagerDaoImpl;
	
	private Session session;
	private Transaction transaction;
	private Task task;
	private Project project;
	private Task taskReturn;
	private Project projectReturn;
	private User user;
	private User userReturn;
	private SessionFactory sessionFactory;
	private List<Task> taskList;
	private List<Project> projectList;
	private List<User> userList;
	private ParentTask parentTask;
	private Criteria criteria;
	
	//private SessionFactory sessionFactory = entityManagerFactory.unwrap(SessionFactory.class);

	@Before
	public void beforeTest(){
	    MockitoAnnotations.initMocks(this);
	    session = Mockito.mock(Session.class);
		transaction = Mockito.mock(Transaction.class);
		task = Mockito.mock(Task.class);
		taskReturn = Mockito.mock(Task.class);
		parentTask = Mockito.mock(ParentTask.class);
		user = Mockito.mock(User.class);
		userReturn = Mockito.mock(User.class);
		sessionFactory = Mockito.mock(SessionFactory.class);
		project = Mockito.mock(Project.class);
		projectReturn = Mockito.mock(Project.class);
		taskList = new ArrayList<Task>();
		projectList = new ArrayList<Project>();
		userList = new ArrayList<User>();
		Mockito.doReturn(sessionFactory).when(entityManagerFactory).unwrap(SessionFactory.class);
		Mockito.doReturn(session).when(sessionFactory).openSession();
		Mockito.doReturn(transaction).when(session).beginTransaction();
	}
	
	@Test
	public void testAddOrMergeTask() {	     
	     Mockito.doNothing().when(session).saveOrUpdate(task);
	     projectManagerDaoImpl.addOrMergeTask(task);
	     assertEquals(task.getTaskId(), taskReturn.getTaskId());
	}

	@Test (expected = RuntimeException.class)
	public void testAddOrMergeTaskRunTimeException() {	 
		Mockito.doThrow(new RuntimeException()).when(session).saveOrUpdate(task);
	    projectManagerDaoImpl.addOrMergeTask(task);
	}
	
	@Test
	public void testDeleteTask() {	     
	     Mockito.doNothing().when(session).load(task, 1);
	     Mockito.doNothing().when(session).delete(task);
	     projectManagerDaoImpl.deleteTask(task);
	     assertEquals(task.getTaskId(), taskReturn.getTaskId());
	}
	
	@Test (expected = RuntimeException.class)
	public void testDeleteTaskException() {	     
	     Mockito.doNothing().when(session).load(task, 1);
	     Mockito.doThrow(new RuntimeException()).when(session).delete(task);
	     projectManagerDaoImpl.deleteTask(task);
	}
	
	@Test
	public void testGetAllTask() {
		createTaskObj();
		criteria = Mockito.mock(Criteria.class);
		Mockito.doReturn(criteria).when(session).createCriteria(Task.class);
		Mockito.doReturn(taskList).when(criteria).list();
	    projectManagerDaoImpl.getAllTask();
	    assertTrue(!taskList.isEmpty());
	}
	
	@Test (expected = RuntimeException.class)
	public void testGetAllTaskException() {
		criteria = Mockito.mock(Criteria.class);
		Mockito.doThrow(new RuntimeException()).when(session).createCriteria(Task.class);
	    projectManagerDaoImpl.getAllTask();
	}
	
	@Test
	public void testGetMatchingTask() {
		criteria = Mockito.mock(Criteria.class);
		Mockito.doReturn(criteria).when(session).createCriteria(Task.class);
		Mockito.doReturn(taskReturn).when(criteria).uniqueResult();
	    Task taskReturn = projectManagerDaoImpl.getMatchingTask(task);
	    assertEquals(task.getTaskId(), taskReturn.getTaskId());
	}
	
	@Test (expected = RuntimeException.class)
	public void testGetMatchingTaskException() {
		criteria = Mockito.mock(Criteria.class);
		Mockito.doReturn(criteria).when(session).createCriteria(Task.class);
		Mockito.doThrow(new RuntimeException()).when(criteria).uniqueResult();
	    Task taskReturn = projectManagerDaoImpl.getMatchingTask(task);
	}
	
	@Test
	public void testAddOrMergeProject() {	     
	     Mockito.doNothing().when(session).saveOrUpdate(project);
	     projectManagerDaoImpl.addOrMergeProject(project);
	     assertEquals(project.getProjectId(), project.getProjectId());
	}
	
	@Test
	public void testDeleteProject() {	     
	     Mockito.doNothing().when(session).load(project, 1);
	     Mockito.doNothing().when(session).delete(project);
	     projectManagerDaoImpl.deleteProject(project);
	     assertEquals(project.getProjectId(), project.getProjectId());
	}
	
	@Test
	public void testGetAllProject() {
		createProjectObj();
		criteria = Mockito.mock(Criteria.class);
		Mockito.doReturn(criteria).when(session).createCriteria(Project.class);
		Mockito.doReturn(projectList).when(criteria).list();
		projectManagerDaoImpl.getAllProject();
	    assertTrue(!projectList.isEmpty());
	}
	
	@Test
	public void testGetMatchingProject() {
		criteria = Mockito.mock(Criteria.class);
		Mockito.doReturn(criteria).when(session).createCriteria(Project.class);
		Mockito.doReturn(projectReturn).when(criteria).uniqueResult();
	    Project projectReturn = projectManagerDaoImpl.getMatchingProject(project);
	    assertEquals(project.getProjectId(), projectReturn.getProjectId());
	}
	
	@Test
	public void testAddOrMergeUser() {	     
	     Mockito.doNothing().when(session).saveOrUpdate(user);
	     projectManagerDaoImpl.addOrMergeUser(user);
	     assertEquals(user.getUser_Id(), user.getUser_Id());
	}
	
	@Test
	public void testDeleteUser() {	     
	     Mockito.doNothing().when(session).load(user, 1);
	     Mockito.doNothing().when(session).delete(user);
	     projectManagerDaoImpl.deleteUser(user);
	     assertEquals(user.getUser_Id(), user.getUser_Id());
	}
	
	@Test
	public void testGetAllUser() {
		createUserObj();
		criteria = Mockito.mock(Criteria.class);
		Mockito.doReturn(criteria).when(session).createCriteria(User.class);
		Mockito.doReturn(userList).when(criteria).list();
		projectManagerDaoImpl.getAllUser();
	    assertTrue(!userList.isEmpty());
	}
	
	@Test
	public void testGetMatchingUser() {
		criteria = Mockito.mock(Criteria.class);
		Mockito.doReturn(criteria).when(session).createCriteria(User.class);
		Mockito.doReturn(userReturn).when(criteria).uniqueResult();
	    User userReturn = projectManagerDaoImpl.getMatchingUser(user);
	    assertEquals(user.getUser_Id(), userReturn.getUser_Id());
	}
	
	private void createTaskObj() {
		//Create a task object		
		task.setTaskName("Task1");
		parentTask.setParentaskName("ParentTask1");
		task.setParentTask(parentTask);
		task.setPriority(20);
		task.setStartDate(new java.sql.Date(new Date(12, 12, 2018).getTime()));
		task.setEndDate(new java.sql.Date(new Date(12, 12, 2018).getTime()));
		taskList.add(task);
	}
	
	@Test
	public void testAddOrMergeParentTask() {	     
	     Mockito.doNothing().when(session).saveOrUpdate(parentTask);
	     projectManagerDaoImpl.addOrMergeParentTask(parentTask);
	     assertEquals(parentTask.getParentId(), parentTask.getParentId());
	}

	@Test (expected = RuntimeException.class)
	public void testAddOrMergeParentTaskRunTimeException() {	 
		Mockito.doThrow(new RuntimeException()).when(session).saveOrUpdate(parentTask);
	    projectManagerDaoImpl.addOrMergeParentTask(parentTask);
	}
	
	private void createProjectObj() {
		//Create a project object
		project.setProject("FSD");
		project.setPriority(25);
		projectList.add(project);
	}
	
	private void createUserObj() {
		//Create a project object
		user.setFirstName("subash");
		user.setLastName("G");
		userList.add(user);
	}
	
}