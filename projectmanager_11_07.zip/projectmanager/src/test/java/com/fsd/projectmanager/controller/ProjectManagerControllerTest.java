package com.fsd.projectmanager.controller;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;

import com.fsd.projectmanager.service.ProjectManagerServiceImpl;
import com.fsd.projectmanager.ProjectManagerApplication;
import com.fsd.projectmanager.controller.ProjectManagerController;
import com.fsd.projectmanager.dao.ParentTask;
import com.fsd.projectmanager.dao.Project;
import com.fsd.projectmanager.dao.Task;
import com.fsd.projectmanager.dao.User;
@RunWith(MockitoJUnitRunner.class)
public class ProjectManagerControllerTest {
	
	@InjectMocks
	private ProjectManagerController projectMngCtrl;
	@Mock
	private ProjectManagerServiceImpl projectManageService;

	private BindingResult bindingResult;
	private ProjectManagerJSON projectManageJSON;
	private List<ProjectManagerJSON> projectManageJSONList;
	private Task task;
	private ParentTask parentTask;
	private Project project;
	private User user;
	private List<Project> projectList;
	private List<User> userList;
	private List<Task> taskList;
	private Set<Task> taskSet;
	private ResponseEntity<Object> statusObj;
	private ResponseEntity<Integer> statusInt;
	private ResponseEntity<ProjectManagerJSON> status;
	
	@Before
    public void before() {		
		MockitoAnnotations.initMocks(this);		
		projectManageJSON = new ProjectManagerJSON();
		task = new Task();
		project = new Project();
		user = new User();
		projectList = new ArrayList<Project>();
		userList = new ArrayList<User>();
		parentTask = new ParentTask();
		taskList = new ArrayList<Task>();
		taskSet = new HashSet<Task>();
		projectManageJSONList = new ArrayList<ProjectManagerJSON>();
		bindingResult = null;
		status = null;
		statusObj = null;
		statusInt = null;
		createJSONTask();
		createProjectObj();
		createUserObj();
		createTaskObj();
    }
	
	@Test
	public void createTask() throws Exception{			
		Mockito.doReturn("Task Added").when(this.projectManageService).addTask(this.task);
        statusObj = projectMngCtrl.createTask(projectManageJSON, bindingResult);
        assertEquals(200,statusObj.getStatusCode().value());		
	}
	
	@Test
	public void updateTask() throws Exception{
		Mockito.doReturn("Task Updated").when(this.projectManageService).updateTask(this.task);
		status = projectMngCtrl.updateTask(projectManageJSON);
        assertEquals(200,status.getStatusCode().value());		
	}
	
	@Test
	public void deleteTask() throws Exception{
		Mockito.doReturn("Task Deleted").when(this.projectManageService).deleteTask(this.task);
		statusInt = projectMngCtrl.deleteTask(task.getTaskId());
        assertEquals(200,statusInt.getStatusCode().value());		
	}
	
	@Test
	public void getTaskList() throws Exception{
		Mockito.doReturn(taskList).when(this.projectManageService).getTaskList();
		projectManageJSONList = projectMngCtrl.getTaskList();
        assertEquals(projectManageJSONList.get(0).getTaskId(),taskList.get(0).getTaskId());		
	}
	
	@Test
	public void createProject() throws Exception{			
		Mockito.doReturn("Project Added").when(this.projectManageService).addProject(this.project);
        statusObj = projectMngCtrl.createProject(projectManageJSON, bindingResult);
        assertEquals(200,statusObj.getStatusCode().value());		
	}
	
	@Test
	public void updateProject() throws Exception{
		Mockito.doReturn("Project Updated").when(this.projectManageService).updateProject(this.project);
		status = projectMngCtrl.updateProject(projectManageJSON);
        assertEquals(200,status.getStatusCode().value());		
	}
	
	@Test
	public void deleteProject() throws Exception{
		Mockito.doReturn("Project Deleted").when(this.projectManageService).deleteProject(this.project);
		statusInt = projectMngCtrl.deleteProject(task.getTaskId());
        assertEquals(200,statusInt.getStatusCode().value());		
	}
	
	@Test
	public void getProjectList() throws Exception{
		Mockito.doReturn(projectList).when(this.projectManageService).getProjectList();
		projectManageJSONList = projectMngCtrl.getProjectList();
        assertEquals(projectManageJSONList.get(0).getProjectId(),projectList.get(0).getProjectId());		
	}
	
	@Test
	public void createUser() throws Exception{			
		Mockito.doReturn("User Added").when(this.projectManageService).addUser(this.user);
        statusObj = projectMngCtrl.createUser(projectManageJSON, bindingResult);
        assertEquals(200,statusObj.getStatusCode().value());		
	}
	
	@Test
	public void updateUser() throws Exception{
		Mockito.doReturn("User Updated").when(this.projectManageService).updateUser(this.user);
		status = projectMngCtrl.updateUser(projectManageJSON);
        assertEquals(200,status.getStatusCode().value());		
	}
	
	@Test
	public void deleteUser() throws Exception{
		Mockito.doReturn("User Deleted").when(this.projectManageService).deleteUser(this.user);
		statusInt = projectMngCtrl.deleteUser(task.getTaskId());
        assertEquals(200,statusInt.getStatusCode().value());		
	}
	
	@Test
	public void getUserList() throws Exception{
		Mockito.doReturn(userList).when(this.projectManageService).getUserList();
		projectManageJSONList = projectMngCtrl.getUserList();
        assertEquals(projectManageJSONList.get(0).getUserId(),userList.get(0).getUser_Id());		
	}
	
	@Test
	public void createParentTask() throws Exception{			
		Mockito.doReturn("Parent Task Added").when(this.projectManageService).addParentTask(this.parentTask);
        statusObj = projectMngCtrl.createParentTask(projectManageJSON, bindingResult);
        assertEquals(200,statusObj.getStatusCode().value());		
	}

	private void createTaskObj() {
		//Create a task object		
		task.setTaskName(projectManageJSON.getTask());
		parentTask.setParentaskName(projectManageJSON.getParentTask());
		task.setParentTask(parentTask);
		task.setPriority(projectManageJSON.getPriority());
		task.setStartDate(new java.sql.Date(projectManageJSON.getStartDate().getTime()));
		task.setEndDate(new java.sql.Date(projectManageJSON.getEndDate().getTime()));
		task.setProject(project);
		task.setUser(user);
		taskList.add(task);
		taskSet.add(task);
	}
	
	private void createProjectObj() {
		//Create a project object		
		project.setProject(projectManageJSON.getProject());
		project.setStartDate(new java.sql.Date(projectManageJSON.getProjectStartDate().getTime()));
		project.setEndDate(new java.sql.Date(projectManageJSON.getProjectEndDate().getTime()));
		project.setPriority(projectManageJSON.getProjectPriority());
		project.setUser(user);
		project.setTask(taskSet);
		projectList.add(project);
	}
	
	private void createUserObj() {
		//Create a user object	
		user.setEmployee_Id(projectManageJSON.getEmployeeId());
		user.setFirstName(projectManageJSON.getFirstName());
		user.setLastName(projectManageJSON.getLastName());
		userList.add(user);
	}

	private void createJSONTask() {
		//Create a JSON Task
		projectManageJSON.setTask("Task1");
		projectManageJSON.setParentTask("ParentTaskl");
		projectManageJSON.setPriority(10);
		projectManageJSON.setStartDate(new Date());
		projectManageJSON.setEndDate(new Date());
		
		projectManageJSON.setProject("FSD1");
		projectManageJSON.setProjectStartDate(new Date());
		projectManageJSON.setProjectEndDate(new Date());
		projectManageJSON.setProjectPriority(20);
		
		projectManageJSON.setEmployeeId(10001);
		projectManageJSON.setFirstName("FN");
		projectManageJSON.setLastName("LN");
	}
}
